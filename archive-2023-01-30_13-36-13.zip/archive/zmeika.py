import pygame                                               # импорт библиотеки

pygame.init()

W = 900
H = 900

sc = pygame.display.set_mode((W, H))                        # регулировать размер дисплея (900 на 900/600 на 400)
pygame.display.set_caption("События от клавиатуры")         # название экрана


WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

FPS = 60                                                    # число кадров в секунду
clock = pygame.time.Clock()

surf = pygame.Surface((25,25))


x = W // 6
y = H // 6
x2 = W // 2
y2 = H // 2

speed = 3
dl = 80
sh = 80
dl2 = 30
sh2 = 30

chetchik = 0


while True:
    for event in pygame.event.get():                           #pygame.event.get() - события, которые уже произошли
        if event.type == pygame.QUIT:
            exit()
        
    sc.fill(WHITE)
    pygame.draw.ellipse(sc, BLUE, (300, 300, 100, 50))

    keys = pygame.key.get_pressed()                         #pygame.key.get_pressed() - кнопки, которые нажаты в данный момент

    pygame.display.update()
    if keys[pygame.K_LEFT]:
        x -= speed

    if keys[pygame.K_RIGHT]:
        x += speed
    if keys[pygame.K_UP]:

        y -= speed
    if keys[pygame.K_DOWN]:

        y += speed
    
    print('x',x)
    print('y',y)
    print('x2',x2)
    print('y2',y2)

    if ((x/2 == x2/2) and (y/2 == y2/2)):
        
        chetchik+=1
        print(chetchik)

    clock.tick(FPS)


#  ceredina = (x//2 and y//2)
#  if ceredina == ceredina 1:
#     chetchik +=1
