import pygame
 
pygame.init()
 
W = 600
H = 400
 
sc = pygame.display.set_mode((W, H))
pygame.display.set_caption("Класс Surface")
# pygame.display.set_icon(pygame.image.load("app.bmp"))
 
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
 
FPS = 60        # число кадров в секунду
clock = pygame.time.Clock()
# bx, by = 0, 150
x, y = 300, 300
# xx = 30
# xy = 80
x1 = 0
y1 = 10
x2 = 20
y2 = 10
speed = 3

# surf = pygame.Surface((xx, xy))                       сделать норм змейку, которая при поровоте меняет туловище 
surf = pygame.Surface(50,50)
surf.fill(RED)
pygame.draw.rect(surf,WHITE, x1,5, y1, 10)
pygame.draw.rect(surf,WHITE, x2,5, y2, 10)

pvrt = 0

while 1:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()

    pygame.display.update()

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        pvrt = 1
        # surf = pygame.Surface((xy, xx))
    surf.fill(RED)
    pygame.draw.rect(surf,WHITE, x2,5, y2, 10)
    pygame.draw.rect(surf,WHITE, x1,5, y1, 10)
        # x -= speed
    if keys[pygame.K_RIGHT]:
        pvrt = 2
        # x += speed
    if keys[pygame.K_UP]:
        pvrt = 3

        # y -= speed
    if keys[pygame.K_DOWN]:
        pvrt = 4
        # y += speed

    if pvrt == 1:
        x-=speed
    if pvrt == 2:
        x+=speed
    if pvrt == 3:
        y-=speed
    if pvrt == 4:
        y+=speed

    pygame.display.update()
    sc.fill(WHITE)
    sc.blit(surf,(x,y))
    clock.tick(FPS)